<div id="sidebar" class="col-lg-3 animated fadeInRight">
    <ul class="nav nav-tabs" id="topMerchant" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="top-merchant-tab" data-toggle="tab" href="#top-merchant" role="tab" aria-controls="top-merchant" aria-selected="true"><i class="fas fa-store mr-2"></i>  TOP <span class="color-warning">Nhà Cung Cấp</span></a>
        </li>
    </ul>
    <div class="tab-content" id="topMerchantContent">
        <div class="tab-pane fade show active" id="top-merchant" role="tabpanel" aria-labelledby="top-merchant-tab">
            Đang cập nhật
        </div>
    </div>
</div> 