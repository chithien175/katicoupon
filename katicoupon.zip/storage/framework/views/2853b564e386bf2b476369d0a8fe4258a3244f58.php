<!doctype html>
<html lang="vi">
    <head>
        <!-- Required meta tags -->
        <meta charset="utf-8">
        
        <!-- Token -->
        <meta name="_token" content="<?php echo e(csrf_token()); ?>" />

        <!-- Google SEO -->
        <title><?php echo $__env->yieldContent('title'); ?></title>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
        <meta name="robots" content="index, follow" />
        <meta name="keywords" content="mã giảm giá, phiếu khuyến mãi, coupons, vouchers, <?php echo $__env->yieldContent('keywords'); ?>">
        <meta name="author" content="Kho Coupon" />
        <link rel="canonical" href="https://khocoupon.net/" />
        <link rel="shortcut icon" type="image/png" href="">

        <!-- FB Open Graph Tags -->
        <meta property="fb:app_id"        content="xxxxxxxxxxxxxx" />
        <meta property="og:url"           content="<?php echo $__env->yieldContent('fb_url'); ?>" />
        <meta property="og:type"          content="<?php echo $__env->yieldContent('fb_type'); ?>" />
        <meta property="og:title"         content="<?php echo $__env->yieldContent('fb_title'); ?>" />
        <meta property="og:description"   content="<?php echo $__env->yieldContent('fb_des'); ?>" />
        <meta property="og:image"         content="<?php echo $__env->yieldContent('fb_img'); ?>" />
   

        
        
        <!-- Bootstrap CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/plugins/bootstrap/css/bootstrap.min.css')); ?>">
        <!-- Fontawesome CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/plugins/fontawesome/css/all.min.css')); ?>">
        <!-- Select2 CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/plugins/select2/select2.min.css')); ?>" />
        <!-- Pace CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/plugins/pace/pace.css')); ?>">
        <!-- Toastr CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/plugins/toastr/toastr.min.css')); ?>">
        <!-- Animate CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/plugins/animate/animate.css')); ?>">
        <!-- Custom CSS -->
        <link rel="stylesheet" href="<?php echo e(asset('/css/custom.css')); ?>">
        <?php echo $__env->yieldContent('css'); ?>
    </head>
    <body>
        <!-- Header -->
        <?php echo $__env->make('partials.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        <div id="content-container" class="container">
            <div class="row">
                <!-- Content Page -->
                <?php echo $__env->yieldContent('content'); ?>

                <!-- Sidebar -->
                <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            </div>
        </div>

        <!-- Footer -->
        <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <!-- Advanced Filter -->
        <?php echo $__env->yieldContent('advanced-filter'); ?>

        <!-- Coupon Modal -->
        <?php echo $__env->yieldContent('coupon-modal'); ?>

        <!-- Optional JavaScript -->
        <!-- jQuery JS -->
        <script src="<?php echo e(asset('/plugins/jquery/jquery-3.3.1.min.js')); ?>"></script>
        <!-- Popper JS -->
        <script src="<?php echo e(asset('/plugins/popper/popper.min.js')); ?>"></script>
        <!-- Bootstrap JS  -->
        <script src="<?php echo e(asset('/plugins/bootstrap/js/bootstrap.min.js')); ?>"></script>
        <!-- Select2 JS -->
        <script src="<?php echo e(asset('/plugins/select2/select2.min.js')); ?>"></script>
        <!-- Pace JS -->
        <script src="<?php echo e(asset('/plugins/pace/pace.min.js')); ?>"></script>
        <!-- Toastr JS -->
        <script src="<?php echo e(asset('/plugins/toastr/toastr.min.js')); ?>"></script>
        <!-- Custom JS -->
        <script src="<?php echo e(asset('/js/custom.js')); ?>"></script>
        <?php echo $__env->yieldContent('js'); ?>
    </body>
</html>