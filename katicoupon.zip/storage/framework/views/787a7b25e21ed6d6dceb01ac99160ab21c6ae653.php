<footer>
    <div class="row">
        <div class="col-lg-12 text-center">
            <p>Trang tổng hợp MÃ GIẢM GIÁ & SIÊU KHUYẾN MÃI lớn nhất Việt Nam</p>
        </div>
    </div>
</footer>