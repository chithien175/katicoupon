<div class="row">
    <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-lg-12">
            <div class="item-group">
                <div class="float-right info">
                    <?php
                        $current = Carbon\Carbon::now();
                        $future = $coupon['end_time'];
                    ?>
                    <div class="end_time"><i class="icon-clock far fa-clock"></i> Còn <?php echo e($current->diffInDays($future) + 1); ?> ngày</div>
                </div>
                <div class="title">
                    <h5>
                        <a href="<?php echo e(route('merchant-filter', $coupon['merchant'])); ?>" class="merchant">[<?php echo e($coupon['merchant']); ?>]</a>
                    </h5>
                    <h5 class="">
                        <a href="<?php echo e($coupon['aff_link']); ?>" class="name" target="_blank"><?php echo e($coupon['name']); ?></a>
                    </h5>
                    <?php $__currentLoopData = $coupon['coupons']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        - <?php echo e($value['coupon_save']); ?>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>