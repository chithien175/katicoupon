<?php $__env->startSection('title', 'Tổng hợp khuyến mãi '.$merchant.' tháng'. date('m') . ' tại khocoupon.net'); ?>
<?php $__env->startSection('description', 'Cập nhật mã giảm giá '.$merchant.', phiếu khuyến mãi '.$merchant.', coupons '.$merchant.', vouchers '.$merchant.'.'); ?>
<?php $__env->startSection('keywords', ''); ?>

<?php $__env->startSection('fb_url', ''); ?>
<?php $__env->startSection('fb_type', ''); ?>
<?php $__env->startSection('fb_title', ''); ?>
<?php $__env->startSection('fb_des', 'Ứng dụng không thể thiếu cho những người mua hàng trực tuyến. Cập nhật mã giảm giá, phiếu khuyến mãi, coupons, vouchers.'); ?>
<?php $__env->startSection('fb_img', ''); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="merchant" class="col-lg-9 mb-4 animated fadeInLeft">
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="promotion-tab" data-toggle="tab" href="#promotion" role="tab" aria-controls="promotion" aria-selected="true"><i class="fas fa-gift mr-2 bell"></i> TỔNG HỢP KHUYẾN MÃI <span class="color-warning"><?php echo e($merchant); ?></span> THÁNG <?php echo e(date('m')); ?></a>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="promotion" role="tabpanel" aria-labelledby="promotion-tab">
            <?php
                $promotions = getAllPromotions($merchant, 15);
            ?>

            <?php echo $__env->make('partials.promotion-list', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('advanced-filter'); ?>
    <?php echo $__env->make('partials.advanced-filter', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('coupon-modal'); ?>
    <?php echo $__env->make('partials.coupon-modal', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        // FUNCTION: Get All Parameters on URL
        function getAllUrlParams(url) {
            var queryString = url ? url.split('?')[1] : window.location.search.slice(1);
            var obj = {};
            if (queryString) {
                queryString = queryString.split('#')[0];
                var arr = queryString.split('&');
                for (var i = 0; i < arr.length; i++) {
                    var a = arr[i].split('=');
                    var paramName = a[0];
                    var paramValue = typeof (a[1]) === 'undefined' ? true : a[1];
                    paramName = paramName.toLowerCase();
                    if (typeof paramValue === 'string') paramValue = paramValue.toLowerCase();
                    if (paramName.match(/\[(\d+)?\]$/)) {
                        var key = paramName.replace(/\[(\d+)?\]/, '');
                        if (!obj[key]) obj[key] = [];
                        if (paramName.match(/\[\d+\]$/)) {
                            var index = /\[(\d+)\]/.exec(paramName)[1];
                            obj[key][index] = paramValue;
                        }
                        else{
                            obj[key].push(paramValue);
                        }
                    } 
                    else{
                        if (!obj[paramName]) {
                            obj[paramName] = paramValue;
                        } else if (obj[paramName] && typeof obj[paramName] === 'string'){
                            obj[paramName] = [obj[paramName]];
                            obj[paramName].push(paramValue);
                        } else {
                            obj[paramName].push(paramValue);
                        }
                    }
                }
            }
            return obj;
        }
        
        // CHECK: Open Coupon Modal
        $(document).ready(function() {
            var promotionId = getAllUrlParams().promotion;
            // CHECK: if have promotionId then call ajax to get coupon info
            if(promotionId){
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="_token"]').attr('content')
                    }
                });
                $.ajax({
                    url: "<?php echo e(route('getCouponByPromotionId')); ?>",
                    method: 'post',
                    data: {
                        promotion_id: promotionId
                    },
                    success: function(result){
                        if(result.status == true){
                            var promotion = result.data;
                            $("#couponModal .modal-title").html('['+promotion.merchant+'] '+promotion.name);
                            $("#couponModal .code-text").val(promotion.coupons[0].coupon_code);
                            $("#couponModal .coupon-des").html(promotion.content);
                            $("#couponModal").modal();
                        }
                        
                    }
                });
            }
        });
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>