<div id="advanced-filter" class="animated fadeInUp">
    <div class="content-filter">
        <form id="advanced-filter-form">
            <?php echo csrf_field(); ?>
            <?php
                $campaigns = getAllCampaigns();
                $merchant = (isset($merchant))?$merchant:'false';
            ?>
            <select class="form-control" id="merchant-select" name="merchant-select">
                <option value="false">Chọn nhà cung cấp cần tìm</option>
                <?php $__currentLoopData = $campaigns['data']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $campaign): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option <?php echo e(($merchant==$campaign['merchant'])?'selected':''); ?> value="<?php echo e($campaign['merchant']); ?>" data-merchant-link="<?php echo e(route('merchant-filter', $campaign['merchant'])); ?>"><?php echo e($campaign['name']); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <button id="advanced-filter-submit" type="submit" class="btn btn-warning">Tìm kiếm</button>
        </form>
    </div>
</div>