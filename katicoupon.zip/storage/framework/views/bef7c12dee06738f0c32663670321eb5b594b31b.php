<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="homepage" class="col-lg-12">
    <ul class="nav nav-tabs" id="myTab" role="tablist">
        <li class="nav-item">
            <a class="nav-link active" id="promotion-tab" data-toggle="tab" href="#promotion" role="tab" aria-controls="promotion" aria-selected="true">Khuyến mãi (hot)</a>
        </li>
        <li class="nav-item">
            <a class="nav-link" id="coupon-tab" data-toggle="tab" href="#coupon" role="tab" aria-controls="coupon" aria-selected="false">Mã giảm giá (new)</a>
        </li>
    </ul>
    <div class="tab-content" id="myTabContent">
        <div class="tab-pane fade show active" id="promotion" role="tabpanel" aria-labelledby="promotion-tab">
            <div class="row">
                <?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-12 item-group">
                        <h5>
                            <a href="#" class="merchant">[<?php echo e($promotion->merchant); ?>]</a><a href="#" class="name"><?php echo e($promotion->name); ?></a>
                        </h5>
                        <p class="info">
                            <?php
                                $current = Carbon\Carbon::now();
                                $future = $promotion->end_time;
                            ?>
                            <span class="recommended mr-2"><i class="icon-check far fa-check-square"></i> Đã xác nhận</span>
                            <span class="end_time"><i class="icon-clock far fa-clock"></i> Còn <?php echo e($current->diffInDays($future) + 1); ?> ngày</span>
                        </p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
        <div class="tab-pane fade" id="coupon" role="tabpanel" aria-labelledby="coupon-tab">
            <div class="row">
                <?php $__currentLoopData = $coupons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $coupon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>