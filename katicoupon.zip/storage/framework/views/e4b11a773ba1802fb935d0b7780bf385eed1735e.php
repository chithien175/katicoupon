<div id="sidebar" class="col-lg-3">
    <ul class="list-group">
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <a href="#">tiki.vn</a>
            <span class="badge badge-primary badge-pill">14</span>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <a href="#">lazada.vn</a>
            <span class="badge badge-primary badge-pill">2</span>
        </li>
        <li class="list-group-item d-flex justify-content-between align-items-center">
            <a href="#">shopee.vn</a>
            <span class="badge badge-primary badge-pill">1</span>
        </li>
    </ul>
</div> 