<?php $__currentLoopData = $promotions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $promotion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="item-group">
        <div class="des">
            <h5>
                <a href="<?php echo e(route('merchant-filter', $promotion['merchant'])); ?>" class="merchant"><i class="fas fa-store"></i> [<?php echo e($promotion['merchant']); ?>]</a>
            </h5>
            <h5 class="click-aff-link">
                <a href="javascript:void(0)" class="name" data-aff-link="<?php echo e($promotion['aff_link']); ?>"><?php echo e($promotion['name']); ?></a>
            </h5>
        </div>
        <?php if(empty($promotion['coupons'])): ?>
        <div class="aff-link-button click-aff-link" data-toggle="tooltip" data-placement="top" title="Click nhận ưu đãi">
            <a href="javascript:void(0)" data-aff-link="<?php echo e($promotion['aff_link']); ?>"><i class="fas fa-tag"></i> CHI TIẾT</a>
        </div>
        <?php else: ?>
        <div class="get-coupon-button click-get-coupon" data-toggle="tooltip" data-placement="top" title="Click nhận mã coupon">
            <a href="javascript:void(0)" data-aff-link="<?php echo e($promotion['aff_link']); ?>" data-redirect-link="<?php echo e(route('merchant-filter', $promotion['merchant'])); ?>?promotion=<?php echo e($promotion['id']); ?>"><i class="fas fa-cut"></i> LẤY MÃ</a>
        </div>
        <?php endif; ?>
        <?php
            $current = Carbon\Carbon::now();
            $future = $promotion['end_time'];
        ?>
        <div class="end_time"><i class="icon-green far fa-clock"></i> Còn <?php echo e($current->diffInDays($future) + 1); ?> ngày</div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- Pagination -->
<?php echo e($promotions->links()); ?>

